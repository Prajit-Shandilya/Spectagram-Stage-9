export const firebaseConfig = {
  apiKey: 'AIzaSyB-D1n8Kf630QSmsP8-8rVMj6wqu1mroyc',

  authDomain: 'spectagram-1c2ad.firebaseapp.com',

  databaseURL: 'https://spectagram-1c2ad-default-rtdb.firebaseio.com',

  projectId: 'spectagram-1c2ad',

  storageBucket: 'spectagram-1c2ad.appspot.com',

  messagingSenderId: '744018390374',

  appId: '1:744018390374:web:d71ac4fc90300da59c2ca7',
};
// Initialize Firebase
