import * as React from 'react';
import { Text, View, StyleSheet } from 'react-native';
import { NavigationContainer } from '@react-navigation/native';
import DrawerNavigator from './component/DrawerNavigator';
import { createStackNavigator } from '@react-navigation/stack';
import Dashboardscreen from './screens/Dashboardscreen';
import Loginscreen from './screens/Loginscreen';
import Loadingscreen from './screens/Loadingscreen';
import * as firebase from 'firebase';

import { firebaseConfig } from './config';
if (!firebase.apps.length) {
  firebase.initializeApp(firebaseConfig);
} else {
  firebase.app();
}
// You can import from local files

const Stack = createStackNavigator();

export default function App() {
  return (
    <NavigationContainer>
      <Stack.Navigator
        initialRouteName="Home"
        screenOptions={{
          headerShown: false,
        }}>
          
        <Stack.Screen name="Loading" component={Loadingscreen} />
        <Stack.Screen name="Login" component={Loginscreen} />
        <Stack.Screen name="Dashboard" component={Dashboardscreen} />
        

      
      </Stack.Navigator>
    </NavigationContainer>
  );
}
