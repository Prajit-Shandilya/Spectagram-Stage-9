import React from 'react';
import { Text, View, StyleSheet } from 'react-native';
import Constants from 'expo-constants';

import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';

import Upload from '../screens/Upload';
import Feedphoto from '../screens/Feedphoto';
import Ionicons from 'react-native-vector-icons/Ionicons';

import { createMaterialBottomTabNavigator } from '@react-navigation/material-bottom-tabs';
import { RFValue } from 'react-native-responsive-fontsize';

const Tab = createBottomTabNavigator();

const BottomTabNavigator = () => {
  return (
    <Tab.Navigator
      labeled={false}
      barStyle={styles.bottomTabsStyle}
      screenOptions={({ route }) => ({
        tabBarIcon: ({ focused, color, size }) => {
          var iconName;
          if (route.name === 'Feedphoto') {
            iconName = focused ? 'book' : 'book-outline';
          } else if (route.name === 'Upload') {
            iconName = focused ? 'create' : 'create-outline';
          }
          return (
            <Ionicons
              name={iconName}
              size={size}
              color={color}
              style={styles.icon}
            />
          );
        },
      })}
      tabBarOptions={{ activeTintColor: 'seagreen', inactiveTintColor: 'black' }}>
      <Tab.Screen name="Feedphoto" component={Feedphoto} />
      <Tab.Screen name="Upload" component={Upload} />
    </Tab.Navigator>
  );
};
export default BottomTabNavigator;

const styles = StyleSheet.create({
  bottomTabsStyle: {
    color: '#2f345d',
    height: '8%',
    borderTopLeftRadius: 30,
    borderTopRightRadius: 30,
    position: 'absolute',
    overflow: 'hidden',
  },
  icon: {
    width: RFValue(30),
    height: RFValue(30),
  },
});
