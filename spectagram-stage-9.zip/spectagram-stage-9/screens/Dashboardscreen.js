import * as React from 'react';
import {NavigationContainer} from '@react-navigation/native';
import DrawerNavigator from '../component/DrawerNavigator';

export default function Dashboardscreen(){
  return(
    <DrawerNavigator/>
  )
}